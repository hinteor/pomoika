#define SDL_REVISION "https://github.com/libsdl-org/SDL.git@8c9beb0c873f6ca5efbd88f1ad2648bfc793b2ac"
#define SDL_REVISION_NUMBER 0
